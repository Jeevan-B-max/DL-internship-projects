import os
import nbformat
from nbconvert.preprocessors import ExecutePreprocessor
import sys
import subprocess
import json

# --- CONFIGURATION ---
# Look for notebooks in the CURRENT folder
SOURCE_DIR = "."  
MODELS_DIR = "models"
ARTIFACTS_DIR = "artifacts"

os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(ARTIFACTS_DIR, exist_ok=True)

def get_python_kernel_name():
    """Finds the valid kernel name for Windows."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "jupyter", "kernelspec", "list", "--json"],
            capture_output=True, text=True
        )
        specs = json.loads(result.stdout)
        kernels = list(specs['kernelspecs'].keys())
        return 'python3' if 'python3' in kernels else kernels[0]
    except:
        return 'python3'

def run_and_extract(notebook_path, kernel_name):
    print(f"🚀 Processing {notebook_path}...")
    
    try:
        with open(notebook_path, 'r', encoding='utf-8') as f:
            nb = nbformat.read(f, as_version=4)

        # Force correct kernel metadata
        nb.metadata.kernelspec = {
            "display_name": "Python 3",
            "language": "python",
            "name": kernel_name
        }

        # --- INJECTION CODE ---
        # This code runs inside the notebook to save the files
        # It looks for 'model' and 'scaler' variables
        esc_models = MODELS_DIR.replace('\\', '/')
        esc_artifacts = ARTIFACTS_DIR.replace('\\', '/')
        nb_name = os.path.splitext(os.path.basename(notebook_path))[0]

        save_code = f"""
import os
import joblib
import tensorflow as tf

try:
    # 1. FIND AND SAVE MODEL
    target_model = None
    if 'reg_model' in locals(): target_model = reg_model
    elif 'model' in locals(): target_model = model
    
    if target_model:
        model_path = "{esc_models}/{nb_name}.h5"
        target_model.save(model_path)
        print(f"SAVED_MODEL: {{model_path}}")
    
    # 2. FIND AND SAVE SCALER
    target_scaler = None
    # List of variable names you used for scalers in your notebooks
    possible_names = ['scaler', 'x_scaler', 'feature_scaler', 'ct']
    
    for name in possible_names:
        if name in locals():
            target_scaler = locals()[name]
            break
    
    if target_scaler:
        # We save it as 'scaler.pkl' for simplicity, or unique name
        scaler_path = "{esc_artifacts}/scaler.pkl" 
        joblib.dump(target_scaler, scaler_path)
        print(f"SAVED_SCALER: {{scaler_path}}")

except Exception as e:
    print(f"SAVE_ERROR: {{e}}")
"""
        nb.cells.append(nbformat.v4.new_code_cell(save_code))

        # EXECUTE
        print(f"   ⏳ Training & Saving...")
        ep = ExecutePreprocessor(timeout=None, kernel_name=kernel_name)
        # We run in current dir so it finds the CSV file
        ep.preprocess(nb, {'metadata': {'path': '.'}})
        print(f"   ✅ Done: {notebook_path}")

    except Exception as e:
        print(f"   ❌ Failed: {str(e)}")

if __name__ == "__main__":
    if sys.platform.startswith('win'):
        import asyncio
        try:
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        except: pass

    kernel_name = get_python_kernel_name()
    
    # Find notebooks
    notebooks = [f for f in os.listdir(SOURCE_DIR) if f.endswith('.ipynb')]
    
    for nb in notebooks:
        run_and_extract(nb, kernel_name)