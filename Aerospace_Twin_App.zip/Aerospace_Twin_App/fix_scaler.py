import pandas as pd
from sklearn.preprocessing import StandardScaler
import joblib
import os

print("🔧 Fixing Scaler...")

# 1. Load your dataset
csv_path = 'control_surface_vibration_modes_100k.csv'

if not os.path.exists(csv_path):
    print(f"❌ Error: Could not find '{csv_path}'. Make sure it is in this folder.")
    exit()

df = pd.read_csv(csv_path)

# 2. Replicate the Preprocessing (One-Hot Encoding)
# This MUST match exactly what you did in the LSTM notebook
if 'Surface_Type' in df.columns and 'Material' in df.columns:
    df_processed = pd.get_dummies(df, columns=['Surface_Type', 'Material'], drop_first=True)
else:
    df_processed = df

# 3. Separate Features (X)
# We drop the target columns to isolate the inputs
target_cols = ['Natural_Freq_Hz', 'Damping_Ratio']
X = df_processed.drop(columns=[c for c in target_cols if c in df_processed.columns])

print(f"   Training scaler on {X.shape[1]} features: {list(X.columns)}")

# 4. Fit the Standard Scaler
scaler = StandardScaler()
scaler.fit(X)

# 5. Save it to the artifacts folder
os.makedirs('artifacts', exist_ok=True)
save_path = 'artifacts/scaler.pkl'
joblib.dump(scaler, save_path)

print(f"✅ Success! Saved new scaler to: {save_path}")
print("👉 You can now refresh your Streamlit app.")