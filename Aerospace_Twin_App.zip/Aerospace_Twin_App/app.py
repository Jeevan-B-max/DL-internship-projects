import streamlit as st
import pandas as pd
import numpy as np
import tensorflow as tf
import joblib
import plotly.graph_objects as go
import os

# ==========================================
# 1. APP CONFIGURATION
# ==========================================
st.set_page_config(
    page_title="Aerospace Digital Twin",
    page_icon="✈️",
    layout="wide"
)

# Custom Styling
st.markdown("""
    <style>
    .main { background-color: #0e1117; color: #ffffff; }
    .stMetric { background-color: #262730; padding: 15px; border-radius: 5px; border: 1px solid #4e4e4e; }
    </style>
    """, unsafe_allow_html=True)

# ==========================================
# 2. LOAD MODEL & SCALER
# ==========================================
@st.cache_resource
def load_assets(model_file):
    # 1. Check Scaler
    if not os.path.exists('artifacts/scaler.pkl'):
        return None, None, "Scaler missing. Run fix_scaler.py"
    
    # 2. Load Scaler
    try:
        scaler = joblib.load("artifacts/scaler.pkl")
    except Exception as e:
        return None, None, f"Error loading scaler: {e}"

    # 3. Check Model
    model_path = f"models/{model_file}"
    if not os.path.exists(model_path):
        return None, None, f"Model file {model_file} not found."

    # 4. Load Model
    try:
        model = tf.keras.models.load_model(model_path)
    except Exception as e:
        return None, None, f"Error loading model: {e}"
        
    return model, scaler, None

# Sidebar Model Selection
st.sidebar.header("⚙️ System Config")
if not os.path.exists('models'):
    st.error("Critical: 'models' folder is missing!")
    model_choice = None
else:
    available_models = [f for f in os.listdir('models') if f.endswith('.h5')]
    if not available_models:
        st.error("No .h5 models found in 'models/'. Run converter script.")
        model_choice = None
    else:
        model_choice = st.sidebar.selectbox("Select AI Model", available_models)

# Load selected assets
model, scaler, err_msg = None, None, None
if model_choice:
    model, scaler, err_msg = load_assets(model_choice)

if err_msg:
    st.sidebar.error(err_msg)


# ==========================================
# 3. USER INPUTS (SIDEBAR)
# ==========================================
st.sidebar.header("🎮 Flight Parameters")

def get_user_input():
    length = st.sidebar.slider("Length (m)", 0.1, 5.0, 1.5)
    width = st.sidebar.slider("Width (m)", 0.1, 2.0, 0.4)
    thickness = st.sidebar.slider("Thickness (m)", 0.001, 0.1, 0.02)
    
    airspeed = st.sidebar.slider("Airspeed (m/s)", 0.0, 400.0, 250.0)
    aoa = st.sidebar.slider("Angle of Attack (deg)", -20.0, 20.0, 5.0)
    
    mode_num = st.sidebar.selectbox("Mode Number", [1, 2, 3])
    
    surface_type = st.sidebar.selectbox("Surface", ["Aileron", "Elevator", "Rudder"])
    # Updated Material options to match CSV data (CarbonFiber instead of Composite)
    material = st.sidebar.selectbox("Material", ["Aluminum", "CarbonFiber", "Titanium"])
    
    return length, width, thickness, airspeed, aoa, mode_num, surface_type, material

length, width, thickness, airspeed, aoa, mode_n, surface_type, material = get_user_input()

# Create Input Data Dictionary
# CRITICAL: Column names here must EXACTLY match what scaler.pkl expects (from one-hot encoding)
input_data = {
    'Length_m': length, 
    'Width_m': width, 
    'Thickness_m': thickness,
    'Airspeed_mps': airspeed, 
    'Angle_of_Attack_deg': aoa, 
    'Mode_Number': mode_n,
    
    # One-Hot Columns (Based on typical pd.get_dummies output)
    'Surface_Type_Elevator': 1 if surface_type == "Elevator" else 0,
    'Surface_Type_Rudder': 1 if surface_type == "Rudder" else 0,
    
    # Fix: Use 'Material_CarbonFiber' to match training data
    'Material_CarbonFiber': 1 if material == "CarbonFiber" else 0,
    'Material_Titanium': 1 if material == "Titanium" else 0
}

# ==========================================
# 4. MAIN DASHBOARD
# ==========================================
st.title("✈️ Aerospace Control Surface Digital Twin")
st.markdown(f"### Vibration Mode Prediction & State Monitoring")

if st.button("Analyze Structural Integrity"):
    if model is None or scaler is None:
        st.error("System not ready. Check sidebar for errors.")
    else:
        try:
            # A. Prepare Data Frame
            df = pd.DataFrame([input_data])
            
            # B. Scale Data
            X_scaled = scaler.transform(df)
            
            # C. Reshape (Required for RNNs)
            X_final = X_scaled
            try:
                # Check if model expects 3D input (LSTM/CNN/GRU often do)
                # Shape: (Samples, TimeSteps, Features)
                if len(model.input_shape) == 3:
                     X_final = X_scaled.reshape(X_scaled.shape[0], 1, X_scaled.shape[1])
            except:
                pass 

            # D. Predict
            preds = model.predict(X_final)

            # --- LOGIC FOR MODEL TYPE ---
            # Check output dimension to decide Visualization strategy
            output_dim = preds.shape[1]
            
            # Case 1: Regression (Frequency & Damping) - LSTM/GRU/Stacked
            if output_dim >= 2 and "cnn" not in model_choice.lower(): 
                freq = float(preds[0][0])
                damping = float(preds[0][1])

                # Display Metrics
                res1, res2 = st.columns(2)
                res1.metric("Predicted Frequency", f"{freq:.2f} Hz")
                res2.metric("Damping Ratio", f"{damping:.4f}")

                # Digital Twin Physics Simulation
                st.subheader("Simulated Vibration Response")
                t = np.linspace(0, 2, 1000)
                # Physics formula for damped oscillation
                y = np.exp(-damping * 2 * np.pi * freq * t) * np.sin(2 * np.pi * freq * t)
                
                fig = go.Figure()
                fig.add_trace(go.Scatter(x=t, y=y, mode='lines', name='Displacement', line=dict(color='#00ccff')))
                fig.update_layout(xaxis_title="Time (s)", yaxis_title="Amplitude", template="plotly_dark")
                st.plotly_chart(fig, use_container_width=True)
                
                # Safety Checks
                if damping < 0.0:
                    st.error("⚠️ DANGER: Flutter Detected (Negative Damping)")
                elif damping < 0.01:
                    st.warning("⚠️ WARNING: Low Damping Margin")
                else:
                    st.success("✅ System Stable")

            # Case 2: Classification (Surface Type) - CNN
            else:
                # Assuming CNN output is probabilities for classes [Aileron, Elevator, Rudder]
                classes = ["Aileron", "Elevator", "Rudder"]
                predicted_index = np.argmax(preds)
                predicted_class = classes[predicted_index] if predicted_index < len(classes) else "Unknown"
                confidence = np.max(preds) * 100
                
                st.info(f"Model is running in CLASSIFICATION mode (CNN).")
                st.metric("Predicted Surface Type", predicted_class)
                st.progress(int(confidence))
                st.write(f"Confidence: {confidence:.1f}%")

        except Exception as e:
            st.error(f"Prediction Failed: {str(e)}")
            st.write("Debug Info - Input Data Columns:")
            st.write(list(df.columns))